copy and paste the given lunar_env in your conda envs folder
or to create your own virtual environment make sure you install following dependencies
python 3.8.18

activate your conda environment
pip install torch==2.0.1+cu117 -f https://download.pytorch.org/whl/cu117/torch_stable.html
pip install gym
pip install moviepy
pip install matplotlib

#to run the codes
python train.py
python test.py